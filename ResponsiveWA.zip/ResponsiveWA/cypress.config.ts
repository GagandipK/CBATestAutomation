const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    "baseUrl": "https://responsivefight.herokuapp.com/",
    "supportFile": "cypress/support/e2e.ts",
    "defaultCommandTimeout": 8000,
    "chromeWebSecurity": false,   
    "viewportWidth": 2000,
    "viewportHeight": 1500,
    "pageLoadTimeout" : 80000,
    "trashAssetsBeforeRuns": false,
    "experimentalSourceRewriting": true,
    "modifyObstructiveCode": true
  }
});
