export function generateRandomString() {
    const randomString = Math.random().toString(36).replace(/[^a-z]+/g, '').substring(0, 7);;
    const prefix = 'web';   
    
    const userName = `${prefix}${randomString}`;
    cy.log(`Random string is : ${userName}`);
    return userName;
  }