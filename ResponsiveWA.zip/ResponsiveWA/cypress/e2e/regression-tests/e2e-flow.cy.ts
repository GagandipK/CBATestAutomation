/// <reference types="cypress" />

describe('E2E for Completing challenges as already Signed Up User', function () {
  beforeEach(function () {  
    cy.fixture('testData.json').as('data');
  });

  it('Login as registered user and complete challenges and verify data on Leadership board', function () {    
    cy.gotoHomePage().then((homePage) => {
        homePage
        .goToLoginPage()
        .loginAsExistingUser(this.data.userName, this.data.password)
        .goToWelcomePage()
        .goToWarningsPage()
        .goToQuestionsPage()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectSecondAnswer()
        .goToNextQuestion()
        .selectSecondAnswer()        
        .goToNextQuestion()
        .selectSecondAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectSecondAnswer()        
        .goToNextQuestion()
        .selectSecondAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToNextQuestion()
        .selectSecondAnswer()        
        .goToNextQuestion()
        .selectFirstAnswer()        
        .goToLeaderBoard()
        .verifyValuesOnDashboard(this.data.userName)
        .goToWelcomePage()
        .verifyTextOnWelcomePage(this.data.textOnWelcomePage)               
       })
    })
  });

