/// <reference types="cypress" />

import ContinueJourneyPage from "../page-objects/ContinueJourneyPage";
import LoginPage from "../page-objects/LoginPage";

describe('E2E for Registering a new user', function () {
    beforeEach(function () {  
      cy.fixture('testData.json').as('data');
    });
  
    it('Register new user', function () {    
        cy.gotoHomePage().then((homePage) => {
            homePage
          .goToSignUpPage()        
          .signUpAsNewUser()
          .then(({userName: uName, password: pwd, lpage: LoginPage}) => {
          LoginPage.loginAsExistingUser(uName, pwd)          
         })                           
         })
      })
    });
  
  