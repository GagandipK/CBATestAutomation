import QuestionsPage from './QuestionsPage';
import LeaderBoardPage from './LeaderBoardPage';

export default class VerifyAnswerPage {
    _continueCTA = () => cy.get('#continue');
   
    goToNextQuestion() {
      this._continueCTA().should('be.visible').click();
      return new QuestionsPage();
    }

    goToLeaderBoard() {
        this._continueCTA().should('be.visible').click();
        return new LeaderBoardPage();
      }
   
  }