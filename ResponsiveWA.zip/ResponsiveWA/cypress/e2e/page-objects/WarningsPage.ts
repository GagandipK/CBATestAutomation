import QuestionsPage from './QuestionsPage';

export default class WarningsPage {
    _startCTAOnWarningModal = () => cy.get('#start');
   
    goToQuestionsPage() {
      this._startCTAOnWarningModal().should('be.visible').click();
     return new QuestionsPage();
    }
   
  }