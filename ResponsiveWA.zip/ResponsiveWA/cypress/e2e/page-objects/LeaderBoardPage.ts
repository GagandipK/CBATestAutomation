import WelcomePage from './WelcomePage';

export default class LeaderBoardPage {
    _userNameText = () => cy.get('tr:nth-child(2) > td:nth-child(1)');
    _scoreValue = () => cy.get('tr:nth-child(2) > td:nth-child(2)');
    _continueCta = () => cy.get('#leaderboard_link');      
   
    verifyValuesOnDashboard(userName: string) {
      this._userNameText()
      .should('be.visible')      
      .should('contain', userName);
      this._scoreValue()
      .should('not.be.null')
      return this;
    }

    goToWelcomePage() {
        this._continueCta().should('be.visible').click();
        return new WelcomePage();
    }
   
  }