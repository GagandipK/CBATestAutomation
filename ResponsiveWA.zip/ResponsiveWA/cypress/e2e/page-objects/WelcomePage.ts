import WarningsPage from './WarningsPage';

export default class WelcomePage {
    _enterAtYourOwnRisk = () => cy.get('#news');
   
   goToWarningsPage() {
    this._enterAtYourOwnRisk().should('be.visible').click();
    return new WarningsPage();
   }

   verifyTextOnWelcomePage(text: string) {
    this._enterAtYourOwnRisk().contains(text)
   }

  }