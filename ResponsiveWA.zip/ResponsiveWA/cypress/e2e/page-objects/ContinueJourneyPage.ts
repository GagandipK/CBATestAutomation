import WelcomePage from './WelcomePage';

export default class ContinueJourneyPage {
    _startCta = () => cy.get('#start');
       
    goToWelcomePage() {
      this._startCta().should('be.visible').click();
      return new WelcomePage();
    }
   
  }