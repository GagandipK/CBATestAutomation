import VerifyAnswerPage from './VerifyAnswerPage';

export default class QuestionsPage {
    _firstAnswerCta = () => cy.get('#answer_1');
    _secondAnswerCta = () => cy.get('#answer_2');
   
    selectFirstAnswer() {
      this._firstAnswerCta().should('be.visible', { timeout: 2000 }).click();
      return new VerifyAnswerPage();
    }

    selectSecondAnswer() {
        this._secondAnswerCta().should('be.visible', { timeout: 2000 }).click();
        return new VerifyAnswerPage();
      }
   
  }