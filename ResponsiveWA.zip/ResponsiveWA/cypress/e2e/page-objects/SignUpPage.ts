import LoginPage from './LoginPage';
import { generateRandomString } from '../helpers/test-helpers';

export default class SignUpPage {
    _userNameTextBox= () => cy.get('#uname');
    _password = () => cy.get('#pwd');
    _repeatPassword = () => cy.get('#psw-repeat');
    _signUpCta = () => cy.get('#signupbtn');
    
    userName = generateRandomString();
    password = generateRandomString();


    signUpAsNewUser() {


      return this._userNameTextBox().should('be.visible').type(this.userName).then(() => {
        this._password().should('be.visible').type(this.password).then(()=> {
          this._repeatPassword().should('be.visible').type(this.password).then(() => {
            this._signUpCta().should('be.visible').click();
          })

        })

      }).then(() => {
        return { userName:this.userName, password: this.password, lpage: new LoginPage() };  

      })
      
      
      
    
          
    }    
   
  }