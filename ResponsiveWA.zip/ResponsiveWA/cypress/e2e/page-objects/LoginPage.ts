import ContinueJourneyPage from './ContinueJourneyPage';

export default class LoginPage {
    _userNameTextBox = () => cy.get('#worrior_username');
    _passwordTextBox = () => cy.get('#worrior_pwd');
    _loginCta = () => cy.get('#warrior');
   
    loginAsExistingUser(userName: string, password: string) {
      this._userNameTextBox().should('be.visible').type(userName);
      this._passwordTextBox().should('be.visible').type(password);
      this._loginCta().should('be.visible').click();
      return new ContinueJourneyPage();
    }    
   
  }