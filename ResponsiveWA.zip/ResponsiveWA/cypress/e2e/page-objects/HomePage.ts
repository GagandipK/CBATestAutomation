import LoginPage from './LoginPage';
import SignUpPage from './SignUpPage';

export default class HomePage {
    _loginCta = () => cy.get('#login');
    _registerCta = () => cy.get('#rego');
   
    goToLoginPage() {
      this._loginCta().should('be.visible').click();
      return new LoginPage();
    }

    goToSignUpPage() {
      this._registerCta().should('be.visible').click();
      return new SignUpPage();
    }
   
  }