using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using SuperVillainBase;

namespace SupervillainAPITesting
{
    public class Tests
    {
        //private string authToken = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJrZXkiOiJnYWdhbmRpcCIsImVtYWlsIjoiZ2FnYW5kaXAzOEBnbWFpbC5jb20iLCJpYXQiOjE2NTk3OTMwNzUsImV4cCI6MTY2MDA1MjI3NX0.Td71XXPM6pifXxRq_s05o5CKWMngJaE4p_bAp0Wsb2Ska609Fviul_nWVArw4mulq_n29tDhnk7k3w0nU8-8Mw";
        //private string url = "https://supervillain.herokuapp.com";
        private static SuperVillainAPITest sv;
        



        [SetUp]
        public void Setup()
        {
            sv = new SuperVillainAPITest();
        }

        [Test]
        public void VerifyToken()
        {
            string verifyResult = sv.verifyToken();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.OK.ToString()));
        }

        [Test]
        public void RegisterUser()
        {
            string verifyResult = sv.registerUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.OK.ToString()));
        }

        [Test]
        public void reRegisterUser()
        {
            string verifyResult = sv.reRegisterUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.BadRequest.ToString()));
        }

        [Test]
        public void authFailUserRegistration()
        {
            string verifyResult = sv.authFailUserRegistration();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.Unauthorized.ToString()));
        }

        [Test]
        public void loginUser()
        {
            string verifyResult = sv.loginUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.OK.ToString()));
        }

        [Test]
        public void loginFailedUser()
        {
            string verifyResult = sv.loginFailedUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.BadRequest.ToString()));
        }

        [Test]
        public void loginAuthFailed()
        {
            string verifyResult = sv.loginAuthFailed();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.Unauthorized.ToString()));
        }


        [Test]
        public void getUserList()
        {
            string verifyResult = sv.getUserList();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.OK.ToString()));
        }

        [Test]
        public void addUser()
        {
            string verifyResult = sv.addUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.Created.ToString()));
        }


        [Test]
        public void updateUser()
        {
            string verifyResult = sv.updateUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.NoContent.ToString()));
        }

        [Test]
        public void deleteUser()
        {
            string verifyResult = sv.deleteUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.NoContent.ToString()));
        }

        [Test]
        public void getLoginUser()
        {
            string verifyResult = sv.getLoginUser();
            Assert.That(verifyResult, Is.EqualTo(HttpStatusCode.OK.ToString()));
        }
    }
}