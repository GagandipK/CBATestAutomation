﻿using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Text.RegularExpressions;


namespace SuperVillainBase
{

    public class User
    {
         public string? username { get; set; }
         public string? password { get; set; }

        public User()
        {
            username = newUserName();
            password = "randomPassword";
            Console.WriteLine("User object instantiated with username: " + username);
        }

        public User(string test)
        {
            username = "testone";
            password = "password";
            Console.WriteLine("User object instantiated with username: " + username);
        }

        private string newUserName()
        {

            string uuid = Guid.NewGuid().ToString();

            try
            {
                return Regex.Replace(uuid, @"-", "", RegexOptions.None, TimeSpan.FromSeconds(1.5));
            }
            catch (RegexMatchTimeoutException)
            {
                return String.Empty;
            }
        }
    }
    public class SuperVillainAPITest
    {
        private string authToken = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJrZXkiOiJnYWdhbmRpcCIsImVtYWlsIjoiZ2FnYW5kaXAzOEBnbWFpbC5jb20iLCJpYXQiOjE2NTk3OTMwNzUsImV4cCI6MTY2MDA1MjI3NX0.Td71XXPM6pifXxRq_s05o5CKWMngJaE4p_bAp0Wsb2Ska609Fviul_nWVArw4mulq_n29tDhnk7k3w0nU8-8Mw";
        private string url = "https://supervillain.herokuapp.com";
        private RestClient client;
        private User user;
        private string? loginAuthToken;

        public SuperVillainAPITest()
        {
            client = new RestClient(url);
            user = new User();
        }

        public string verifyToken()
        {

            RestRequest request = new RestRequest("/auth/verifytoken", Method.Get);
            request.AddHeader("Authorization", authToken);

            RestResponse response = client.Execute(request);

            Console.WriteLine("ResponseContent: " + response.Content);

            return response.StatusCode.ToString();

        }

        public string registerUser()
        {

            //Preparing request
            RestRequest request = new RestRequest("/auth/user/register", Method.Post);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", user.username);
            request.AddParameter("password", user.password);


            //Executing request. expected output the user should be registered successfully
            RestResponse registerResponse = client.Execute(request);

            Console.Write("Registering User: " + user.username);

            //Assert Status code = 200
            return registerResponse.StatusCode.ToString();

        }

        public string reRegisterUser()
        {
            //Preparing request
            RestRequest request = new RestRequest("/auth/user/register", Method.Post);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", "testexample1");
            request.AddParameter("password", "testexample1");

            //Executing request with same parameters again. Expected output the API should return user already exists.
            RestResponse reRegisterResponse = client.Execute(request);
            Console.Write("Re-Registering User: " + user.username);
            //Assert Status code = 400
            if (reRegisterResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                Console.WriteLine("User reRegistration failed as expected");

                if (reRegisterResponse.Content != null)
                {
                    dynamic respContent = JObject.Parse(reRegisterResponse.Content);
                    string detail = respContent.error.detail;
                    Console.WriteLine("Message received at Re-Registration: " + detail);
                }
            }

            return reRegisterResponse.StatusCode.ToString();

            
        }

        public string authFailUserRegistration()
        {

            //Preparing request
            RestRequest request = new RestRequest("/auth/user/register", Method.Post);
            // User to be used for Auth Failure TestCase
            User authTestCaseUser = new User();

            //Preparing request

            request.AddHeader("Authorization", "XYZ");
            request.AddParameter("username", user.username);
            request.AddParameter("password", user.password);

            //Executing request with same parameters again. Expected output the API should return user already exists.
            RestResponse authTestCaseResponse = client.Execute(request);

            //Assert Status code = 401
            if (authTestCaseResponse.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                Console.WriteLine("User reRegistration failed as expected");

                if (authTestCaseResponse.Content != null)
                {
                    Console.WriteLine(authTestCaseResponse.Content);
                    dynamic authTestCaseRespContent = JObject.Parse(authTestCaseResponse.Content);

                    string detail = authTestCaseRespContent.error;
                    Console.WriteLine("Message received at Auth failure: " + detail);
                }
            }

            return authTestCaseResponse.StatusCode.ToString();
           

        }

        public string loginUser()
        {
            RestRequest request = new RestRequest("/auth/user/login", Method.Post);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", "testexample1");
            request.AddParameter("password", "testexample1");

            RestResponse response = client.Execute(request);
            Console.WriteLine("Login User response: " + response.Content);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Login Successful for user: " + user.username);

                dynamic jsonObject = JObject.Parse(response.Content);
                loginAuthToken = jsonObject.token;

            }

            return response.StatusCode.ToString();

        }

        public string loginFailedUser()
        {
            RestRequest request = new RestRequest("/auth/user/login", Method.Post);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", "testexample1");
            request.AddParameter("password", "X");

            RestResponse response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                Console.WriteLine("Login failed for user: " + user.username);
            }

            return response.StatusCode.ToString();

        }

        public string loginAuthFailed()
        {
            RestRequest request = new RestRequest("/auth/user/login", Method.Post);
            request.AddHeader("Authorization", "X");
            request.AddParameter("username", user.username);
            request.AddParameter("password", user.password + "X");

            RestResponse response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                Console.WriteLine("Auth failed while trying to login for user: " + user.username);
            }

            return response.StatusCode.ToString();

        }

        public string getUserList()
        {
            RestRequest request = new RestRequest("/v1/user", Method.Get);
            request.AddHeader("Authorization", authToken);

            RestResponse response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                if (response.Content != null)
                {
                    Console.WriteLine(response.Content);
                    dynamic respContent = JArray.Parse(response.Content);
                    if (respContent.Count > 0)
                    {
                        Console.WriteLine("Printing list of users:");
                        Console.WriteLine("Username|Score");
                        foreach (var s in respContent)
                        {
                            Console.WriteLine(s.username + "|" + s.score);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Nothing was returned by the API Call");
                    }
                    //Console.WriteLine("Message received at Auth failure: " + respContent.length);
                }
            }

            return response.StatusCode.ToString();

        }

        public string addUser()
        {


            RestRequest request = new RestRequest("/v1/user", Method.Post);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", user.username);
            request.AddParameter("score", 0);

            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            if (response.StatusCode == System.Net.HttpStatusCode.Created)
            {
                Console.WriteLine("User Created: " + user.username);

            }

            return response.StatusCode.ToString();



        }
        public string updateUser()
        {
            RestRequest request = new RestRequest("/v1/user", Method.Put);
            request.AddHeader("Authorization", authToken);
            request.AddParameter("username", "testexample1");
            request.AddParameter("score", new Random().Next(0,1000));

            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                Console.WriteLine("User Updated: " + user.username);

            }

            return response.StatusCode.ToString();
        }

        public string deleteUser()
        {
            RestRequest request = new RestRequest("/v1/user", Method.Delete);
            request.AddHeader("Authorization", authToken);
            request.AddHeader("delete-key", "a273c631e93441249458db96b6e67977");

            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                Console.WriteLine("User Deleted: " + "a273c631e93441249458db96b6e67977");

            }

            return response.StatusCode.ToString();


        }

        public string getLoginUser()
        {
            this.loginUser();
            Console.WriteLine("Getting Login User");
            RestRequest request = new RestRequest("/v1/user/" + "testexample1", Method.Get);
            request.AddHeader("Authorization", loginAuthToken);

            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("User fetched: " + user.username);

            }

            return response.StatusCode.ToString();
        }

    }
}



